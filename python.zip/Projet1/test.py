
print(1)