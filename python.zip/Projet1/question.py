class Question:
    def __init__(self, texte, choix, reponse):
        self.texte = texte # Importe la question
        self.choix = choix # Importe les choix
        self.reponse = reponse.lower() # Importe la réponse "lower" ou "Upper" est obligatoire car la réponse saisie est sensible à la casse

# Fait la comparaison de la réponse envoyée par l'utilisateur pour la comparer avec la réponse de la question en cours
    def verifier_reponse(self, reponse_utilisateur):
        return reponse_utilisateur.lower() == self.reponse