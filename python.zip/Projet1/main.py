# IMPORTATION DES CLASSES
from qcm import QCM
from question import Question

# Définition du main
def main():
    qcm = QCM() #Création de l'objet main pour y introduire les questions pour appeler la classe QCM dans qcm.py

    qcm.ajouter_question(Question("Combien de protons dans un Uranium 235 ?", ["85", "92", "97"], "b"))
    qcm.ajouter_question(Question("Qu'est ce qui est jaune et qui attend ?", ["Monique", "Bob l'éponge", "Jonathan"], "c"))
    qcm.ajouter_question(Question("Quel est le pays le plus grand ?", ["Chine", "Antarctique", "Russie"], "c"))
    qcm.ajouter_question(Question("Qui a peint la Joconde ?", ["Van Gogh", "Leonard de Vinci", "Picasso"], "b"))
    qcm.ajouter_question(Question("Quel est le plus grand océan ?", ["Atlantique", "Pacifique", "Indien"], "b"))
    qcm.ajouter_question(Question("Quelle planète est la plus proche du soleil ?", ["Mercure", "Venus", "Mars"], "a"))
    qcm.ajouter_question(Question("Quel est le plus petit pays du monde ?", ["Monaco", "Vatican", "Liechtenstein"], "b"))
    qcm.ajouter_question(Question("Quel est la capitale du Japon ?", ["Kyoto", "Osaka", "Tokyo"], "c"))
    qcm.ajouter_question(Question("Quel est le symbole chimique de l'eau ?", ["HO", "O2", "H2O"], "c"))
    qcm.ajouter_question(Question("La bonne réponse à cette question est : La réponse C", ["La réponse C", "Il ment", "C'est moi !"], "a"))

    # Pose les questions et afficher le score
    qcm.poser_questions()
    qcm.affichage_score()

if __name__ == "__main__":
    main()