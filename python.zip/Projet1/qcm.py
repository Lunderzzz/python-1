import random
from question import Question

# Définition de la class QCM
class QCM:
    def __init__(self):
        self.questions = []  # Liste vide pour stocker les réponses
        self.score = 0  # Initialise le score à 0

    def ajouter_question(self, question):  # Méthode pour ajouter les questions dans la liste créée précédemment
        self.questions.append(question)  # Ajoute à la fin de la liste

    def poser_questions(self):
        random.shuffle(self.questions)  # Création d'un mélange des questions
        for i, question in enumerate(self.questions):  # Indexation des questions
            print(f"Question {i + 1}: {question.texte}")  # On affiche la question

            # Mélange des choix
            choix_melanges = random.sample(question.choix, len(question.choix))
            
            # Mettre à jour la bonne réponse en fonction du nouvel ordre des choix
            bonne_reponse_index = choix_melanges.index(question.choix[ord(question.reponse) - 97])
            question.reponse = chr(97 + bonne_reponse_index)  # On met à jour la réponse avec la nouvelle lettre

            # Affichage des choix
            for idx, choix in enumerate(choix_melanges):
                print(f"{chr(97 + idx)}) {choix}")

            # Demande de la réponse de l'utilisateur
            reponse = input("Choisir a, b ou c : ").strip().lower()
            if question.verifier_reponse(reponse):  # Vérification de la réponse
                print("Bonne réponse !\n")
                self.score += 1
            else:
                # Affichage de la bonne réponse avec la nouvelle position
                print(f"Faux, la bonne réponse était: {question.reponse}) {choix_melanges[bonne_reponse_index]}\n")

    def affichage_score(self):
        print(f"\n Score final : {self.score}/{len(self.questions)}")  # Affichage du score
