import unittest
from question import Question

# Test unitaire pour vérifier que le programme s'exécute de la manière attendu. On fera le test avec la réponse A, on pourrait très bien le faire avec B ou C
# On importe la classe Question.py pour vérifier la réponse à notre question
# self fonctionne comme un pointeur qui va contenir les 3 arguments passés en paramètre dans le constructeur pour la fonction verifier la réponse

class TestQuestion(unittest.TestCase):
    def test_verifier_reponse_correcte(self):
        question = Question("Test", ["a", "b", "c"], "a")
        self.assertTrue(question.verifier_reponse("a"))

    def test_verifier_reponse_incorrecte(self):
        question = Question("Test", ["a", "b", "c"], "a")
        self.assertFalse(question.verifier_reponse("b"))

if __name__ == "__main__":
    unittest.main() # Unittest est une librairie utilisé pour tester les réponses à chaque question