import random
import string

class GenerateurMotDePasse:
    def __init__(self, minuscules=0, majuscules=0, chiffres=0, speciaux=0):
        self.caracteres_speciaux = ">?/%^+[]#}!@<|;:',.$&*()-_={"
        self.minuscules = minuscules
        self.majuscules = majuscules
        self.chiffres = chiffres
        self.speciaux = speciaux

    def generer_mot_de_passe(self):
        # Créé une liste vide pour stocker les caractères du mot de passe
        mot_de_passe = []

        # Ajoute les types de caractères spécifiés
        mot_de_passe.extend(random.choices(string.ascii_lowercase, k=self.minuscules))
        mot_de_passe.extend(random.choices(string.ascii_uppercase, k=self.majuscules))
        mot_de_passe.extend(random.choices(string.digits, k=self.chiffres))
        mot_de_passe.extend(random.choices(self.caracteres_speciaux, k=self.speciaux))

        # Mélange et retourne le mot de passe sous forme de chaine de caractères
        random.shuffle(mot_de_passe)
        return ''.join(mot_de_passe)
