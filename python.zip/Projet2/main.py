from generateur_mot_de_passe import GenerateurMotDePasse
from test_mot_de_passe import TestMotDePasse
from generateur_passphrase import GenerateurPassphrase

def afficher_menu():
    print("\n0 - Générateur de mot de passe")
    print("1 - Générateur de passphrase")
    print("2 - Quitter")

def demander_infos_mot_de_passe():
    minuscules = int(input('Nombre de minuscules : '))
    majuscules = int(input('Nombre de majuscules : '))
    chiffres = int(input('Nombre de chiffres : '))
    speciaux = int(input('Nombre de caractères spéciaux : '))
    return minuscules, majuscules, chiffres, speciaux

def demander_nombre_mots_passphrase():
    return int(input("Nombre de mots de la passphrase : "))

def main():
    choix = ""
    while choix != '2':
        afficher_menu()
        choix = input("\nChoisir entre 0 et 2 : ")

        if choix == "0":
            minuscules, majuscules, chiffres, speciaux = demander_infos_mot_de_passe()
            generateur = GenerateurMotDePasse(minuscules, majuscules, chiffres, speciaux)
            mot_de_passe = generateur.generer_mot_de_passe()

            print(f"\nMot de passe généré : {mot_de_passe}")
            
            entropie = TestMotDePasse.calculer_entropie(mot_de_passe)
            force = TestMotDePasse.evaluer_force(mot_de_passe)

            print(f"\nEntropie : {entropie:.2f} bits - Force : {force}")

        elif choix == "1":
            nombre_mots = demander_nombre_mots_passphrase()
            generateur_passphrase = GenerateurPassphrase()
            passphrase = generateur_passphrase.generer_passphrase(nombre_mots)
            print(f"\nPassphrase générée : {passphrase}")

        elif choix == '2':
            print("Arrêt du programme")

if __name__ == "__main__":
    main()
