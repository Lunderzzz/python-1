import random

class GenerateurPassphrase:
    def __init__(self, fichier_mots="wordlist.txt"):

        #Initialise le générateur de passphrase en chargeant une liste de mots depuis un fichier.
        #Chaque ligne du fichier contient un mot utilisable dans la passphrase.

        with open(fichier_mots, 'r') as fichier:
            self.liste_mots = [ligne.strip().split()[1] for ligne in fichier]

    def generer_passphrase(self, nombre_mots=5): # Génère une passphrase en sélectionnant aléatoirement un certain nombre de mots dans la liste chargée
        return ' '.join(random.choices(self.liste_mots, k=nombre_mots))