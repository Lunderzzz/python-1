import math

class TestMotDePasse:
    @staticmethod
    def calculer_entropie(mot_de_passe):
        # Définition de la taille de l'alphabet possible
        alphabet = {
            'minuscule': 26,
            'majuscule': 26,
            'chiffre': 10,
            'special': 32
        }

        taille_alphabet = 0

        # Vérification des types de caractères présents dans le mot de passe
        if any(c.islower() for c in mot_de_passe):
            taille_alphabet += alphabet['minuscule']
        if any(c.isupper() for c in mot_de_passe):
            taille_alphabet += alphabet['majuscule']
        if any(c.isdigit() for c in mot_de_passe):
            taille_alphabet += alphabet['chiffre']
        if any(c in "!@#$%^&*()-_=+[]{}|;:',.<>?/" for c in mot_de_passe):
            taille_alphabet += alphabet['special']

        # Calcul de l'entropie : longueur * log2(taille alphabet)
        return len(mot_de_passe) * math.log2(taille_alphabet) if taille_alphabet > 0 else 0

    @staticmethod
    def evaluer_force(mot_de_passe):
        entropie = TestMotDePasse.calculer_entropie(mot_de_passe)
        if entropie < 50:
            return "Faible"
        elif entropie < 80:
            return "Moyenne"
        return "Forte"
